/* 
Name :Jhansi Yarlagadda
Course Name: Advanced Website Design and Management 
Date: 16-01-2017
TDescription : This script is called by MyprogramICT_2.html its returns the forms elements*/

function myFunction() {
    var x = document.getElementById("frm1");
    var text = "";
    var i;
    for (i = 0; i < x.length ;i++) {
        text += x.elements[i].value + "<br>";
    }
    document.getElementById("demo").innerHTML = text;
}
